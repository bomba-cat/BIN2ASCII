import random as r
for i in range(12):
    print(r.randint(1,10))
print("Made with BIN2ASCII")